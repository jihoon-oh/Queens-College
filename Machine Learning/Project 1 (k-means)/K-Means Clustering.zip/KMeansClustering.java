/**
 * Given a specific data set, performs K-Means clustering and calculates IV, EV, and IV/EV
 * <b>NOTE:</b> This only works for the specific data set given by Professor Yuan.
 * The parameters of the data structures and function parameters used must be changed if there is a different data set.
 * 
 * @author Jihoon Oh
 * @since 2016-10-05
 */

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

public class KMeansClustering {
	public static void main(String[] args) throws Exception{
		double[][] dataSet = new double[210][7];
		double[][] centroidSet = new double[3][7];
		ArrayList<Integer>[] clusterSet = (ArrayList<Integer>[]) new ArrayList[3];
		initializeClusterSet(clusterSet);
		readFile(args[0], dataSet);
		generateCentroids(dataSet, centroidSet);
		printCentroidSet(centroidSet, false);
		assignClusters(dataSet, centroidSet, clusterSet);
		printCentroidSet(centroidSet, true);
		printFinalValues(dataSet, centroidSet, clusterSet);
	}

	/**
	 * Initialize the cluster set to solve null pointer exception errors
	 * 
	 * @param clusterSet
	 */
	public static void initializeClusterSet(ArrayList<Integer>[] clusterSet) {
		for(int i=0; i < clusterSet.length; i++) {
			clusterSet[i] = new ArrayList<Integer>();
		}
	}
	
	/**
	 * Reads the input file and stores data into dataSet
	 * 
	 * @param file
	 * @param dataSet
	 * @throws FileNotFoundException
	 */
	public static void readFile(String file, double[][] dataSet) throws FileNotFoundException{
		Scanner in = new Scanner(new FileReader(file));
		String line;
		String[] lineAry;
		for(int row = 0; row < dataSet.length; row++) {
			line = in.nextLine();
			lineAry = line.split("\\s+");
			for(int col = 0; col < dataSet[0].length; col++) {
				dataSet[row][col] = Double.parseDouble(lineAry[col]);
			}
		}
		in.close();
	}
	
	/**
	 * Generates random centroids by copying properties from random rows
	 * 
	 * @param centroidSet
	 */
	public static void generateCentroids(double[][] dataSet, double[][] centroidSet) {
		int randomRow;
		for(int centroid=0; centroid < centroidSet.length; centroid++) {
			for(int property = 0; property < dataSet[0].length; property++) {
				randomRow = randInt(0, dataSet.length - 1);
				centroidSet[centroid][property] = dataSet[randomRow][property];
				// Use the code below for Step 6
				// centroidSet[centroid][property] = 0;
			}
		}
	}
	
	/**
	 * Generates a random integer between min and max, both inclusive
	 * 
	 * @param min
	 * @param max
	 * @return
	 */
	public static int randInt(int min, int max) {
	    Random rand = new Random();
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    return randomNum;
	}
		
	/**
	 * <li>
	 * Assign data points to clusters
	 * Update centroids
	 * Repeat until all data points have been correctly assigned
	 * </li>
	 * 
	 * @param dataSet
	 * @param centroidSet
	 * @param clusterSet
	 */
	public static void assignClusters(double[][] dataSet, double[][] centroidSet, ArrayList<Integer>[] clusterSet) {
		double minDist, dist;
		boolean needToUpdate = true; // Flag to determine whether to continue to assign or not
		while(needToUpdate) { // While there are data points in the wrong cluster
			needToUpdate = false;
			for(int row = 0; row < dataSet.length; row++) {
				minDist = 999999;  // Set distance to a high number for initial comparison
				for(int cluster = 0; cluster < clusterSet.length; cluster++) { 
					if(clusterSet[cluster].contains(row)) {
						minDist = euclideanDistance(dataSet[row], centroidSet[cluster]);
					}
				}
				for(int centroid = 0; centroid < centroidSet.length; centroid++) {
					dist = euclideanDistance(dataSet[row], centroidSet[centroid]);
					if(dist < minDist) { // If new centroid with lower distance is found
						minDist = dist;
						removeDataFromCluster(clusterSet, row); // Remove this data from other clusters, if it exists
						clusterSet[centroid].add(row); // Add this data to the correct cluster
						needToUpdate = true; // Set flag to true to make sure centroids update again
					}
				}
			}
			updateCentroids(dataSet, centroidSet, clusterSet);
		}
	}
	
	/**
	 * Calculates the euclidean distance given two arrays which contain the seven properties
	 * <p>
	 * [area, perimeter, length, etc.]
	 * 
	 * @param i
	 * @param j
	 * @return
	 */
	public static double euclideanDistance(double[] i, double[] j) {
		double sum = 0;
		for(int attr = 0; attr < i.length && attr < j.length; attr++) {
			sum += Math.pow(i[attr] - j[attr], 2);
		}
		return Math.sqrt(sum);
	}
	
	/**
	 * Given a data point, removes all instances of that data point from all clusters
	 * 
	 * @param clusterSet
	 * @param row
	 */
	public static void removeDataFromCluster (ArrayList<Integer>[] clusterSet, int row) {
		int rowIndex; // Row index because remove(row) removes the index row, which may not exist
		for(int cluster = 0; cluster < clusterSet.length; cluster++) {
			if(clusterSet[cluster].contains(row)) {
				rowIndex = clusterSet[cluster].indexOf(row);
				clusterSet[cluster].remove(rowIndex);
			}
		}
	}
	
	/**
	 * Updates the centroids according to new data points in that cluster
	 * <p>
	 * This is the way it works:
	 * </p>
	 * <p>
	 * Area of new centroid = average of all areas of data points in that cluster
	 * Perimeter of new centroid = average of all perimeters of data points in that cluster
	 * Continue on for the rest of data properties
	 * 
	 * @param dataSet
	 * @param centroidSet
	 * @param clusterSet
	 */
	public static void updateCentroids(double[][] dataSet, double[][] centroidSet, ArrayList<Integer>[] clusterSet) {
		for(int cluster=0; cluster < clusterSet.length; cluster++) {
			double sumArea = 0;
			double sumPerimeter = 0;
			double sumCompactness = 0;
			double sumLengthKernel = 0;
			double sumWidthKernel = 0;
			double sumAsymmetry = 0;
			double sumLengthGroove = 0;
			for(int row : clusterSet[cluster]) { // Summation of all data points in cluster with respect to its properties
				sumArea += dataSet[row][0];
				sumPerimeter += dataSet[row][1];
				sumCompactness += dataSet[row][2];
				sumLengthKernel += dataSet[row][3];
				sumWidthKernel += dataSet[row][4];
				sumAsymmetry += dataSet[row][5];
				sumLengthGroove += dataSet[row][6];	
			}
			centroidSet[cluster][0] = sumArea / clusterSet[cluster].size();
			centroidSet[cluster][1] = sumPerimeter / clusterSet[cluster].size();
			centroidSet[cluster][2] = sumCompactness / clusterSet[cluster].size();
			centroidSet[cluster][3] = sumLengthKernel / clusterSet[cluster].size();
			centroidSet[cluster][4] = sumWidthKernel / clusterSet[cluster].size();
			centroidSet[cluster][5] = sumAsymmetry / clusterSet[cluster].size();
			centroidSet[cluster][6] = sumLengthGroove / clusterSet[cluster].size();
		}		
	}
	
	/**
	 * Calculates and returns Intercluster Variability
	 * 
	 * @param dataSet
	 * @param centroidSet
	 * @param clusterSet
	 * @return
	 */
	public static double calculateIV(double[][] dataSet, double[][] centroidSet, ArrayList<Integer>[] clusterSet) {
		double sum = 0;
		for(int cluster = 0; cluster < clusterSet.length; cluster++) {
			for(int row : clusterSet[cluster]) {
				sum += euclideanDistance(dataSet[row], centroidSet[cluster]);
			}
		}
		return sum;
	}
	
	/**
	 * Calculates and returns Extracluster Variability
	 * 
	 * @param dataSet
	 * @param clusterSet
	 * @return
	 */
	public static double calculateEV(double[][] dataSet, ArrayList<Integer>[] clusterSet) {
		double sum = 0;
		for(int cluster = 0; cluster < clusterSet.length; cluster++) {
			for(int i : clusterSet[cluster]) {
				for(int j : clusterSet[(cluster+1) % 3]) { // Mod 3 so it goes from (0,1), (1,2), and (2,0)
					sum += euclideanDistance(dataSet[i], dataSet[j]);
				}
			}
		}
		return sum / dataSet.length;
	}
	
	public static void printFinalValues(double[][] dataSet, double[][] centroidSet, ArrayList<Integer>[] clusterSet) {
		double iV = calculateIV(dataSet, centroidSet, clusterSet);
		double eV = calculateEV(dataSet, clusterSet);
		System.out.println("Final IV: " + iV);
		System.out.println("Final EV: " + eV);
		System.out.println("Final IV/EV: " + iV/eV);
	}
	
	/**
	 * For debug purposes. Prints the centroid set
	 * 
	 * @param centroidSet
	 */
	public static void printCentroidSet(double[][] centroidSet, boolean isFinal) {
		if(!isFinal) System.out.println("Here are the initial values for the centroids:");
		else System.out.println("Here are the final values for the centroids:");
		for(int i=0; i < centroidSet.length; i++) {
			System.out.print("Centroid " + i + ": ");
			for(int j=0; j < centroidSet[0].length; j++) {
				System.out.print(centroidSet[i][j] + " ");
			}
			System.out.println();
		}
	}
	
	/**
	 * For debug purposes. Prints the cluster set
	 * 
	 * @param clusterSet
	 */
	public static void printClusterSet(ArrayList<Integer>[] clusterSet) {
		for(int i=0; i<clusterSet.length; i++) {
			for(int j=0; j<clusterSet[i].size(); j++) {
				System.out.print(clusterSet[i].get(j) + " ");
			}
			System.out.println();
		}
	}
}
