This is a standard Java file. Just compile it and run like any other ordinary Java file.
IMPORTANT: Do not forget to put the path of the data file as the first argument, args[0]. 